-- Smithy Anomaly Probe v0.1.1
-- Read-only REFramework probe for Monster Hunter Rise: Sunbreak.
-- Goal: discover the runtime objects/fields that change when the player
-- highlights different weapon/armor upgrade entries at the Smithy.

local MOD_NAME = "Smithy Anomaly Probe"
local VERSION = "0.1.1"
local OUTPUT_FILE = "smithy_probe_results_v0101.json"

local state = {
    snapshots = {},
    status = "Ready. Open the Smithy, highlight an upgrade, then capture a snapshot.",
    capture_count = 0,
    include_all_singleton_names = true,
    max_fields_per_object = 100,
    nested_depth = 1,
}

local interesting_terms = {
    "smith", "weapon", "armor", "armour", "equip", "item", "craft", "forge",
    "upgrade", "tree", "recipe", "material", "gui", "fsm", "cursor", "select",
    "facility", "shop", "menu", "overwear", "hyakuryu", "custom", "augment"
}

local function lower(s)
    if s == nil then return "" end
    return string.lower(tostring(s))
end

local function contains_interesting_term(s)
    local v = lower(s)
    for _, term in ipairs(interesting_terms) do
        if string.find(v, term, 1, true) then
            return true
        end
    end
    return false
end

local function safe_call(fn, fallback)
    local ok, result = pcall(fn)
    if ok then return result end
    return fallback
end

local function get_type_name(obj)
    if obj == nil then return nil end
    return safe_call(function()
        local td = obj:get_type_definition()
        if td == nil then return nil end
        return td:get_full_name()
    end, nil)
end

local function stringify_value(value)
    if value == nil then return nil end

    local t = type(value)
    if t == "boolean" or t == "number" or t == "string" then
        return value
    end

    local type_name = get_type_name(value)
    if type_name ~= nil then
        return {
            kind = "managed_object",
            type = type_name,
            value = safe_call(function() return tostring(value) end, "<managed object>")
        }
    end

    return safe_call(function() return tostring(value) end, "<unprintable>")
end

local function dump_object(obj, depth, seen)
    if obj == nil then return nil end
    depth = depth or 0
    seen = seen or {}

    local obj_string = safe_call(function() return tostring(obj) end, "<object>")
    if seen[obj_string] then
        return { cycle = true, value = obj_string }
    end
    seen[obj_string] = true

    local td = safe_call(function() return obj:get_type_definition() end, nil)
    if td == nil then
        return { value = obj_string }
    end

    local result = {
        type = safe_call(function() return td:get_full_name() end, "<unknown>"),
        value = obj_string,
        fields = {}
    }

    local fields = safe_call(function() return td:get_fields() end, {}) or {}
    local count = 0

    for _, field in ipairs(fields) do
        if count >= state.max_fields_per_object then
            result.truncated = true
            break
        end

        local field_name = safe_call(function() return field:get_name() end, "<unknown>")
        local field_type = safe_call(function()
            local ft = field:get_type()
            if ft then return ft:get_full_name() end
            return nil
        end, nil)

        -- Skip static fields when probing an instance; they are usually noise.
        local is_static = safe_call(function() return field:is_static() end, false)
        if not is_static then
            local value = safe_call(function() return field:get_data(obj) end, nil)
            local entry = {
                type = field_type,
                value = stringify_value(value)
            }

            -- For one level, recursively inspect nested managed objects whose
            -- field/type names look relevant to Smithy/equipment/menu state.
            if depth < state.nested_depth and value ~= nil then
                local nested_type = get_type_name(value)
                if nested_type ~= nil and (contains_interesting_term(field_name) or contains_interesting_term(nested_type)) then
                    entry.nested = dump_object(value, depth + 1, seen)
                end
            end

            result.fields[field_name] = entry
            count = count + 1
        end
    end

    return result
end

local function collect_managed_singletons()
    local all_types = {}
    local interesting = {}
    local singletons = safe_call(function() return sdk.get_managed_singletons() end, nil)

    if singletons == nil then
        return all_types, interesting, "sdk.get_managed_singletons() returned nil"
    end

    for key, obj in pairs(singletons) do
        if obj ~= nil then
            local type_name = get_type_name(obj)
            if type_name == nil then
                type_name = safe_call(function() return tostring(key) end, "<unknown>")
            end

            table.insert(all_types, type_name)

            if contains_interesting_term(type_name) then
                table.insert(interesting, dump_object(obj, 0, {}))
            end
        end
    end

    table.sort(all_types, function(a, b) return tostring(a) < tostring(b) end)
    table.sort(interesting, function(a, b) return tostring(a.type) < tostring(b.type) end)

    return all_types, interesting, nil
end

local candidate_type_names = {
    "snow.gui.GuiManager",
    "snow.gui.MessageManager",
    "snow.data.FacilityDataManager",
    "snow.data.EquipDataManager",
    "snow.data.WeaponDataManager",
    "snow.data.ItemDataManager",
    "snow.player.PlayerManager",
    "snow.gui.fsm.GuiFsmManager",
    "snow.gui.fsm.GuiManager",
}

local function collect_candidate_type_metadata()
    local result = {}

    for _, type_name in ipairs(candidate_type_names) do
        local td = safe_call(function() return sdk.find_type_definition(type_name) end, nil)
        if td ~= nil then
            local entry = {
                type = type_name,
                fields = {},
                methods = {}
            }

            local fields = safe_call(function() return td:get_fields() end, {}) or {}
            for _, field in ipairs(fields) do
                local field_name = safe_call(function() return field:get_name() end, "<unknown>")
                local field_type = safe_call(function()
                    local ft = field:get_type()
                    if ft then return ft:get_full_name() end
                    return nil
                end, nil)
                table.insert(entry.fields, { name = field_name, type = field_type })
            end

            local methods = safe_call(function() return td:get_methods() end, {}) or {}
            for _, method in ipairs(methods) do
                local method_name = safe_call(function() return method:get_name() end, "<unknown>")
                if contains_interesting_term(method_name) or string.find(lower(method_name), "get", 1, true) or string.find(lower(method_name), "select", 1, true) then
                    table.insert(entry.methods, method_name)
                end
            end

            result[type_name] = entry
        end
    end

    return result
end

local function save_results()
    local payload = {
        mod = MOD_NAME,
        version = VERSION,
        purpose = "Discover Smithy selection/upgrade/material runtime state",
        output_file = OUTPUT_FILE,
        snapshot_count = #state.snapshots,
        snapshots = state.snapshots,
    }

    local ok, err = pcall(function()
        json.dump_file(OUTPUT_FILE, payload, 2)
    end)

    if ok then
        state.status = "Saved " .. tostring(#state.snapshots) .. " snapshot(s) to reframework/data/" .. OUTPUT_FILE
    else
        state.status = "Save failed: " .. tostring(err)
    end
end

local function capture_snapshot()
    state.capture_count = state.capture_count + 1
    state.status = "Capturing snapshot " .. tostring(state.capture_count) .. "..."

    local all_types, interesting, singleton_error = collect_managed_singletons()

    local snapshot = {
        index = state.capture_count,
        clock = os.clock(),
        singleton_error = singleton_error,
        interesting_singletons = interesting,
        candidate_type_metadata = collect_candidate_type_metadata(),
    }

    if state.include_all_singleton_names then
        snapshot.all_singleton_types = all_types
    end

    table.insert(state.snapshots, snapshot)
    save_results()
end

local function ui_text_wrapped(text)
    -- Older REFramework ImGui bindings (including the user's current build)
    -- do not expose imgui.text_wrapped(). Fall back to plain text instead of
    -- throwing an error that disables the script UI.
    if type(imgui.text_wrapped) == "function" then
        imgui.text_wrapped(text)
    else
        imgui.text(text)
    end
end

re.on_draw_ui(function()
    if imgui.tree_node(MOD_NAME .. " v" .. VERSION) then
        ui_text_wrapped("Read-only discovery probe. It does not modify equipment, materials, quests, or save data.")
        ui_text_wrapped("Use it while moving between different Smithy weapon/armor upgrade entries so we can compare what changes in memory.")
        imgui.spacing()

        local changed
        changed, state.include_all_singleton_names = imgui.checkbox("Include all managed singleton type names", state.include_all_singleton_names)
        changed, state.nested_depth = imgui.slider_int("Nested probe depth", state.nested_depth, 0, 2)
        changed, state.max_fields_per_object = imgui.slider_int("Max fields per object", state.max_fields_per_object, 25, 200)

        imgui.spacing()
        if imgui.button("Capture current Smithy state") then
            capture_snapshot()
        end

        imgui.same_line()
        if imgui.button("Save / export JSON") then
            save_results()
        end

        if imgui.button("Clear snapshots") then
            state.snapshots = {}
            state.capture_count = 0
            state.status = "Snapshots cleared."
        end

        imgui.spacing()
        imgui.text("Snapshots in memory: " .. tostring(#state.snapshots))
        ui_text_wrapped("Status: " .. tostring(state.status))
        ui_text_wrapped("Output: reframework/data/" .. OUTPUT_FILE)
        imgui.tree_pop()
    end
end)

log.info("[" .. MOD_NAME .. "] v" .. VERSION .. " loaded")
