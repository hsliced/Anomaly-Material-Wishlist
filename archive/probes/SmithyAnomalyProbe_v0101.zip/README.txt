Smithy Anomaly Probe v0.1.1
===========================

Purpose
-------
This is a read-only REFramework discovery probe for Monster Hunter Rise: Sunbreak.
It is meant to help us find the game object that represents the CURRENTLY HIGHLIGHTED
Smithy weapon/armor upgrade and, eventually, the material requirements for that entry.

Install
-------
Vortex: Install the ZIP from file. The archive already contains the correct
        reframework/autorun/ layout.

Manual: Copy:
        reframework/autorun/SmithyAnomalyProbe_v0101.lua
        into your MonsterHunterRise game folder, preserving the folder structure.

Restart
-------
If the game is already running, restart Monster Hunter Rise so REFramework loads the script.

Test sequence
-------------
1. Open REFramework -> Script Generated UI -> Smithy Anomaly Probe v0.1.1.
2. Before opening the Smithy, click "Capture current Smithy state" once.
3. Open the Smithy weapon upgrade/crafting tree.
4. Highlight a weapon upgrade that needs ordinary materials. Capture.
5. Move to a DIFFERENT weapon upgrade. Capture again.
6. Highlight an endgame/Sunbreak upgrade that requires an anomaly material. Capture.
7. If possible, switch to an armor upgrade/crafting screen and capture once there too.
8. Click "Save / export JSON".

Send back this file:
    MonsterHunterRise/reframework/data/smithy_probe_results_v0101.json

v0.1.1 fix
----------
- Fixes the startup UI error on REFramework builds that do not provide imgui.text_wrapped().
- Adds a compatibility fallback to imgui.text().

What this version is looking for
--------------------------------
- Managed singleton types that appear only while Smithy menus are active.
- Fields whose values change when the highlighted weapon/armor node changes.
- GUI/FSM/equipment/crafting/material objects we can follow in the next probe.

Safety
------
This probe only reads runtime objects and writes its own diagnostic JSON file.
It does not alter equipment, inventory, upgrade costs, quests, or save data.
