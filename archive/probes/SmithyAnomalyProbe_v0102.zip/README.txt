Smithy Anomaly Probe v0.1.2
===========================

Read-only REFramework discovery probe for Monster Hunter Rise: Sunbreak.

WHAT CHANGED IN v0.1.2
- Versioned JSON output: reframework/data/smithy_probe_results_v0102.json
- JSON includes "probe_version": "0.1.2"
- JSON is created/updated automatically when the script loads.
- JSON is automatically saved again after every Capture current Smithy state.
- Clearing snapshots also immediately updates the JSON.
- Added more Qurious/Anomaly/augmentation-related discovery keywords.
- Keeps the v0.1.1 compatibility fallback for REFramework builds without imgui.text_wrapped().

INSTALL
1. Add this ZIP to Vortex using Install From File.
2. Enable/deploy the mod.
3. If Sunbreak is already running, use REFramework ScriptRunner -> Reset Scripts / reload scripts.
   A full game restart should normally not be required.

TEST
1. Open the Smithy.
2. Open Qurious Weapon Crafting -> Add Anomaly Slot.
3. Highlight a level that visibly shows Required Materials.
4. Open REFramework -> Script Generated UI -> Smithy Anomaly Probe v0.1.2.
5. Click Capture current Smithy state.
6. Move to another augmentation level/material requirement and capture again.
7. Repeat for 3-5 materially different entries if possible.

OUTPUT
reframework/data/smithy_probe_results_v0102.json

The JSON should exist as soon as v0.1.2 successfully loads, even with zero snapshots.
Send that JSON back for analysis.
